import { ScrollView, Text, View, TouchableOpacity, Alert, Share } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { CollapsibleSection } from "@/components/collapsible-section";
import { useColors } from "@/hooks/use-colors";
import { Clipboard } from "react-native";
import { saveSummaryToHistory } from "@/lib/history-utils";

export default function ResultsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { data, transcript } = useLocalSearchParams();

  let result: any = null;
  try {
    result = data ? JSON.parse(data as string) : null;
  } catch (error) {
    console.error("Failed to parse result:", error);
  }

  // Save summary to history when screen loads
  useEffect(() => {
    if (result && transcript) {
      saveSummaryToHistory(transcript as string, result).catch((error) => {
        console.error("Failed to save to history:", error);
      });
    }
  }, [result, transcript]);

  if (!result) {
    return (
      <ScreenContainer className="p-4 items-center justify-center">
        <Text className="text-foreground text-lg">Failed to load results</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          className="mt-4 bg-primary px-6 py-2 rounded-lg"
          activeOpacity={0.8}
        >
          <Text className="text-background font-semibold">Go Back</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await Clipboard.setString(text);
      Alert.alert("Copied", `${label} copied to clipboard`);
    } catch (error) {
      Alert.alert("Error", "Failed to copy to clipboard");
    }
  };

  const handleShare = async () => {
    try {
      const summaryText = `Summary: ${result.summary?.join("\n") || "N/A"}\n\nAssignments: ${
        result.assignments?.map((a: any) => `${a.task} (Due: ${a.due_date})`).join("\n") || "N/A"
      }\n\nExams: ${
        result.exams?.map((e: any) => `${e.exam} (${e.date})`).join("\n") || "N/A"
      }\n\nAction Items: ${
        result.actionItems?.map((a: any) => `[${a.priority}] ${a.text}`).join("\n") || "N/A"
      }`;

      await Share.share({
        message: summaryText,
        title: "Meeting Summary",
      });
    } catch (error) {
      Alert.alert("Error", "Failed to share");
    }
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="flex-row items-center justify-between mb-4">
          <TouchableOpacity onPress={() => router.back()} className="p-2">
            <Text className="text-primary text-lg font-semibold">← Back</Text>
          </TouchableOpacity>
          <Text className="text-xl font-bold text-foreground">Results</Text>
          <TouchableOpacity onPress={handleShare} className="p-2">
            <Text className="text-primary text-lg">📤</Text>
          </TouchableOpacity>
        </View>

        {/* Summary Section */}
        <CollapsibleSection title="Summary" icon="doc.text" defaultOpen={true}>
          <View className="gap-2">
            {result.summary && Array.isArray(result.summary) ? (
              result.summary.map((point: string, idx: number) => (
                <View key={idx} className="flex-row gap-2">
                  <Text className="text-primary font-bold">•</Text>
                  <Text className="flex-1 text-foreground text-sm leading-relaxed">{point}</Text>
                </View>
              ))
            ) : (
              <Text className="text-muted text-sm">No summary available</Text>
            )}
            <TouchableOpacity
              onPress={() =>
                copyToClipboard(
                  result.summary?.join("\n") || "",
                  "Summary"
                )
              }
              className="mt-3 py-2 px-3 bg-surface rounded border border-border"
            >
              <Text className="text-primary text-sm font-semibold text-center">📋 Copy Summary</Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* Assignments Section */}
        <CollapsibleSection title="Assignments" icon="checkmark.circle.fill" defaultOpen={true}>
          <View className="gap-3">
            {result.assignments && Array.isArray(result.assignments) && result.assignments.length > 0 ? (
              result.assignments.map((assignment: any, idx: number) => (
                <View key={idx} className="bg-background rounded p-3 border border-border">
                  <Text className="font-semibold text-foreground text-sm">{assignment.task}</Text>
                  {assignment.due_date && (
                    <Text className="text-muted text-xs mt-1">📅 Due: {assignment.due_date}</Text>
                  )}
                  {assignment.details && (
                    <Text className="text-muted text-xs mt-1">{assignment.details}</Text>
                  )}
                </View>
              ))
            ) : (
              <Text className="text-muted text-sm">No assignments found</Text>
            )}
            <TouchableOpacity
              onPress={() =>
                copyToClipboard(
                  result.assignments
                    ?.map((a: any) => `${a.task} (Due: ${a.due_date})`)
                    .join("\n") || "",
                  "Assignments"
                )
              }
              className="mt-3 py-2 px-3 bg-surface rounded border border-border"
            >
              <Text className="text-primary text-sm font-semibold text-center">📋 Copy Assignments</Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* Exams Section */}
        <CollapsibleSection title="Exams" icon="calendar" defaultOpen={true}>
          <View className="gap-3">
            {result.exams && Array.isArray(result.exams) && result.exams.length > 0 ? (
              result.exams.map((exam: any, idx: number) => (
                <View key={idx} className="bg-background rounded p-3 border border-border">
                  <Text className="font-semibold text-foreground text-sm">{exam.exam}</Text>
                  {exam.date && (
                    <Text className="text-muted text-xs mt-1">📅 Date: {exam.date}</Text>
                  )}
                  {exam.prep_notes && (
                    <Text className="text-muted text-xs mt-1">💡 {exam.prep_notes}</Text>
                  )}
                </View>
              ))
            ) : (
              <Text className="text-muted text-sm">No exams found</Text>
            )}
            <TouchableOpacity
              onPress={() =>
                copyToClipboard(
                  result.exams?.map((e: any) => `${e.exam} (${e.date})`).join("\n") || "",
                  "Exams"
                )
              }
              className="mt-3 py-2 px-3 bg-surface rounded border border-border"
            >
              <Text className="text-primary text-sm font-semibold text-center">📋 Copy Exams</Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* Action Items Section */}
        <CollapsibleSection title="Action Items" icon="exclamationmark.circle.fill" defaultOpen={true}>
          <View className="gap-3">
            {result.actionItems && Array.isArray(result.actionItems) && result.actionItems.length > 0 ? (
              result.actionItems.map((item: any, idx: number) => (
                <View key={idx} className="bg-background rounded p-3 border border-border">
                  <View className="flex-row items-start gap-2">
                    <View
                      className={`px-2 py-1 rounded ${
                        item.priority === "High"
                          ? "bg-error"
                          : item.priority === "Medium"
                            ? "bg-warning"
                            : "bg-success"
                      }`}
                    >
                      <Text className="text-background text-xs font-bold">{item.priority}</Text>
                    </View>
                    <Text className="flex-1 text-foreground text-sm">{item.text}</Text>
                  </View>
                  {item.assignee && (
                    <Text className="text-muted text-xs mt-2">👤 {item.assignee}</Text>
                  )}
                </View>
              ))
            ) : (
              <Text className="text-muted text-sm">No action items found</Text>
            )}
            <TouchableOpacity
              onPress={() =>
                copyToClipboard(
                  result.actionItems
                    ?.map((a: any) => `[${a.priority}] ${a.text}`)
                    .join("\n") || "",
                  "Action Items"
                )
              }
              className="mt-3 py-2 px-3 bg-surface rounded border border-border"
            >
              <Text className="text-primary text-sm font-semibold text-center">📋 Copy Actions</Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* Detected Dates */}
        {result.detectedDates && result.detectedDates.length > 0 && (
          <View className="mt-4 bg-surface rounded-lg p-4 border border-border">
            <Text className="text-sm font-semibold text-foreground mb-2">📅 Detected Dates</Text>
            <Text className="text-xs text-muted">{result.detectedDates.join(", ")}</Text>
          </View>
        )}

        {/* Bottom spacing */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
