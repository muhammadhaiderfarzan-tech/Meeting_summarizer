import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator, Alert } from "react-native";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import { trpc } from "@/lib/trpc";
import { useColors } from "@/hooks/use-colors";

const SAMPLE_TRANSCRIPT = `Prof. Lee: Welcome to CS101. Today we'll cover algorithms and data structures. 
Homework 1: Implement bubble sort and merge sort. Due next Friday, March 20. 
Group project assigned: Build an AI summarizer MVP. Teams of 3, due April 10. 
Midterm exam on March 25, covering chapters 1-4. Focus on sorting algorithms and complexity analysis.
Action: Please email me any questions by tomorrow. 
Also, don't forget to submit your project proposal by March 15.`;

export default function HomeScreen() {
  const [transcript, setTranscript] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const colors = useColors();
  const summarizeMutation = trpc.summarizer.summarize.useMutation();

  const handleSummarize = async () => {
    if (!transcript.trim()) {
      Alert.alert("Empty Transcript", "Please enter a transcript to summarize.");
      return;
    }

    setIsLoading(true);
    try {
      const result = await summarizeMutation.mutateAsync({
        transcript: transcript.trim(),
      });

      if (result.success) {
        // Navigate to results screen with the data
        router.push({
          pathname: "/results",
          params: {
            data: JSON.stringify(result.data),
            transcript: transcript.trim(),
          },
        });
      }
    } catch (error) {
      Alert.alert(
        "Error",
        error instanceof Error ? error.message : "Failed to summarize transcript"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadSample = () => {
    setTranscript(SAMPLE_TRANSCRIPT);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Header */}
          <View className="items-center gap-2 mb-4">
            <Text className="text-3xl font-bold text-foreground">🎓 Meeting Summarizer</Text>
            <Text className="text-sm text-muted text-center">
              Paste your lecture or meeting transcript below
            </Text>
          </View>

          {/* Transcript Input */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Transcript</Text>
            <TextInput
              value={transcript}
              onChangeText={setTranscript}
              placeholder="Paste your lecture/meeting transcript here..."
              placeholderTextColor={colors.muted}
              multiline
              numberOfLines={10}
              className="bg-surface border border-border rounded-lg p-4 text-foreground"
              editable={!isLoading}
            />
          </View>

          {/* Summarize Button */}
          <TouchableOpacity
            onPress={handleSummarize}
            disabled={isLoading}
            className={`rounded-lg py-4 px-6 items-center justify-center ${
              isLoading ? "bg-primary opacity-60" : "bg-primary"
            }`}
            activeOpacity={0.8}
          >
            {isLoading ? (
              <View className="flex-row items-center gap-2">
                <ActivityIndicator color={colors.background} size="small" />
                <Text className="text-background font-semibold">Processing...</Text>
              </View>
            ) : (
              <Text className="text-background font-semibold text-base">📝 Summarize & Extract</Text>
            )}
          </TouchableOpacity>

          {/* Load Sample Button */}
          <TouchableOpacity
            onPress={handleLoadSample}
            disabled={isLoading}
            className="rounded-lg py-3 px-6 items-center border border-primary"
            activeOpacity={0.7}
          >
            <Text className="text-primary font-semibold">📋 Load Sample Transcript</Text>
          </TouchableOpacity>

          {/* Info Card */}
          <View className="bg-surface rounded-lg p-4 border border-border mt-4">
            <Text className="text-sm font-semibold text-foreground mb-2">How it works:</Text>
            <Text className="text-xs text-muted leading-relaxed">
              1. Paste your lecture or meeting notes{"\n"}
              2. Tap "Summarize & Extract"{"\n"}
              3. Get key points, assignments, exams, and action items{"\n"}
              4. Copy or save results for later
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
