import { ScrollView, Text, View, TouchableOpacity, Switch, Alert, Linking } from "react-native";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useThemeContext } from "@/lib/theme-provider";

// TODO: Replace these URLs with your actual policy URLs
const PRIVACY_POLICY_URL = "https://example.com/privacy";
const TERMS_OF_SERVICE_URL = "https://example.com/terms";

export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const { setColorScheme } = useThemeContext();
  const [isDarkMode, setIsDarkMode] = useState(colorScheme === "dark");

  const handleThemeToggle = (value: boolean) => {
    setIsDarkMode(value);
    setColorScheme(value ? "dark" : "light");
  };

  const handleAbout = () => {
    Alert.alert(
      "About",
      `AI Meeting Summarizer\n\nVersion: 1.0.0\n\nA mobile app for students to quickly summarize lectures and meetings, extract assignments, exam reminders, and action items using AI.\n\nBuilt with Expo, React Native, and powered by advanced language models.`
    );
  };

  const handlePrivacy = async () => {
    try {
      await Linking.openURL(PRIVACY_POLICY_URL);
    } catch (error) {
      Alert.alert(
        "Error",
        "Unable to open privacy policy. Please visit: " + PRIVACY_POLICY_URL
      );
    }
  };

  const handleTerms = async () => {
    try {
      await Linking.openURL(TERMS_OF_SERVICE_URL);
    } catch (error) {
      Alert.alert(
        "Error",
        "Unable to open terms of service. Please visit: " + TERMS_OF_SERVICE_URL
      );
    }
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Text className="text-2xl font-bold text-foreground mb-6">⚙️ Settings</Text>

        {/* Theme Section */}
        <View className="bg-surface rounded-lg p-4 mb-4 border border-border">
          <Text className="text-lg font-semibold text-foreground mb-4">Appearance</Text>

          <View className="flex-row items-center justify-between">
            <View className="flex-1">
              <Text className="text-foreground font-medium">Dark Mode</Text>
              <Text className="text-muted text-sm mt-1">
                {isDarkMode ? "Enabled" : "Disabled"}
              </Text>
            </View>
            <Switch
              value={isDarkMode}
              onValueChange={handleThemeToggle}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.background}
            />
          </View>
        </View>

        {/* About Section */}
        <View className="bg-surface rounded-lg p-4 mb-4 border border-border">
          <Text className="text-lg font-semibold text-foreground mb-4">About</Text>

          <TouchableOpacity
            onPress={handleAbout}
            className="py-3 px-4 border border-border rounded-lg mb-2"
          >
            <Text className="text-foreground font-medium">About This App</Text>
          </TouchableOpacity>

          <View className="py-3 px-4 border border-border rounded-lg">
            <Text className="text-muted text-sm mb-1">Version</Text>
            <Text className="text-foreground font-medium">1.0.0</Text>
          </View>
        </View>

        {/* Legal Section */}
        <View className="bg-surface rounded-lg p-4 mb-4 border border-border">
          <Text className="text-lg font-semibold text-foreground mb-4">Legal</Text>

          <TouchableOpacity
            onPress={handlePrivacy}
            className="py-3 px-4 border border-border rounded-lg mb-2 flex-row items-center justify-between"
            activeOpacity={0.7}
          >
            <Text className="text-foreground font-medium">Privacy Policy</Text>
            <Text className="text-primary">→</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleTerms}
            className="py-3 px-4 border border-border rounded-lg flex-row items-center justify-between"
            activeOpacity={0.7}
          >
            <Text className="text-foreground font-medium">Terms of Service</Text>
            <Text className="text-primary">→</Text>
          </TouchableOpacity>
        </View>

        {/* Info Card */}
        <View className="bg-surface rounded-lg p-4 border border-border">
          <Text className="text-sm font-semibold text-foreground mb-2">💡 Tips</Text>
          <Text className="text-xs text-muted leading-relaxed">
            • Paste your full lecture or meeting transcript for best results{"\n"}
            • The app uses AI to extract key information automatically{"\n"}
            • All summaries are saved locally on your device{"\n"}
            • You can search and view past summaries anytime
          </Text>
        </View>

        {/* Bottom spacing */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
