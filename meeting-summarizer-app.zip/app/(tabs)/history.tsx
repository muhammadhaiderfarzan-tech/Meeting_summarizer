import { ScrollView, Text, View, TouchableOpacity, FlatList, Alert, TextInput } from "react-native";
import { useState, useCallback, useEffect } from "react";
import { useFocusEffect } from "@react-navigation/native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import { useColors } from "@/hooks/use-colors";
import { getHistory, deleteHistoryItem, clearHistory } from "@/lib/history-utils";
import type { HistoryItem } from "@/lib/history-utils";

export default function HistoryScreen() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [filteredHistory, setFilteredHistory] = useState<HistoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const colors = useColors();

  const loadHistory = useCallback(async () => {
    try {
      setIsLoading(true);
      const items = await getHistory();
      setHistory(items);
      if (searchQuery.trim() === "") {
        setFilteredHistory(items);
      } else {
        const query = searchQuery.toLowerCase();
        setFilteredHistory(
          items.filter(
            (item) =>
              item.preview.toLowerCase().includes(query) ||
              new Date(item.createdAt).toLocaleDateString().includes(query)
          )
        );
      }
    } catch (error) {
      console.error("Failed to load history:", error);
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  const handleDelete = (id: string) => {
    Alert.alert("Delete", "Remove this summary from history?", [
      { text: "Cancel", onPress: () => {} },
      {
        text: "Delete",
        onPress: async () => {
          try {
            await deleteHistoryItem(id);
            const updated = history.filter((item) => item.id !== id);
            setHistory(updated);
          } catch (error) {
            Alert.alert("Error", "Failed to delete item");
          }
        },
        style: "destructive",
      },
    ]);
  };

  const handleViewResult = (item: HistoryItem) => {
    router.push({
      pathname: "/results",
      params: {
        data: JSON.stringify(item.result),
        transcript: item.transcript,
      },
    });
  };

  const handleClearAll = () => {
    Alert.alert("Clear All", "Delete all history items?", [
      { text: "Cancel", onPress: () => {} },
      {
        text: "Clear",
        onPress: async () => {
          try {
            await clearHistory();
            setHistory([]);
          } catch (error) {
            Alert.alert("Error", "Failed to clear history");
          }
        },
        style: "destructive",
      },
    ]);
  };

  if (isLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">Loading history...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-4">
      <View className="flex-1">
        {/* Header */}
        <View className="mb-4">
          <Text className="text-2xl font-bold text-foreground mb-3">📋 History</Text>

          {/* Search */}
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search summaries..."
            placeholderTextColor={colors.muted}
            className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
          />
        </View>

        {/* History List */}
        {filteredHistory.length === 0 ? (
          <View className="flex-1 items-center justify-center">
            <Text className="text-muted text-lg mb-2">
              {history.length === 0 ? "No summaries yet" : "No results found"}
            </Text>
            {history.length === 0 && (
              <Text className="text-muted text-sm text-center">
                Your saved summaries will appear here
              </Text>
            )}
          </View>
        ) : (
          <FlatList
            data={filteredHistory}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => handleViewResult(item)}
                className="bg-surface rounded-lg p-4 mb-3 border border-border"
                activeOpacity={0.7}
              >
                <View className="flex-row items-start justify-between gap-2">
                  <View className="flex-1">
                    <Text className="text-sm text-muted mb-1">
                      {new Date(item.createdAt).toLocaleString()}
                    </Text>
                    <Text className="text-foreground font-semibold text-sm mb-2" numberOfLines={2}>
                      {item.preview}
                    </Text>
                    <View className="flex-row gap-2">
                      <TouchableOpacity
                        onPress={() => handleViewResult(item)}
                        className="flex-1 py-2 px-3 bg-primary rounded"
                        activeOpacity={0.8}
                      >
                        <Text className="text-background text-xs font-semibold text-center">View</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleDelete(item.id)}
                        className="py-2 px-3 bg-error rounded"
                        activeOpacity={0.8}
                      >
                        <Text className="text-background text-xs font-semibold">🗑️</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            )}
          />
        )}

        {/* Clear All Button */}
        {history.length > 0 && (
          <TouchableOpacity
            onPress={handleClearAll}
            className="mt-4 py-3 px-4 border border-error rounded-lg"
            activeOpacity={0.8}
          >
            <Text className="text-error font-semibold text-center">Clear All History</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScreenContainer>
  );
}
