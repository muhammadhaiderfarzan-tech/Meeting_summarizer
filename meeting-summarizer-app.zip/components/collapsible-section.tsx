import { View, Text, TouchableOpacity } from "react-native";
import { useState } from "react";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

interface CollapsibleSectionProps {
  title: string;
  icon: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export function CollapsibleSection({
  title,
  icon,
  children,
  defaultOpen = true,
}: CollapsibleSectionProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const colors = useColors();

  return (
    <View className="mb-4 bg-surface rounded-lg border border-border overflow-hidden">
      <TouchableOpacity
        onPress={() => setIsOpen(!isOpen)}
        className="flex-row items-center justify-between p-4 bg-surface"
        activeOpacity={0.7}
      >
        <View className="flex-row items-center gap-3 flex-1">
          <IconSymbol name={icon as any} size={24} color={colors.primary} />
          <Text className="text-lg font-semibold text-foreground flex-1">{title}</Text>
        </View>
        <IconSymbol
          name={isOpen ? "chevron.up" : "chevron.down"}
          size={20}
          color={colors.muted}
        />
      </TouchableOpacity>

      {isOpen && (
        <View className="px-4 py-3 border-t border-border bg-background">
          {children}
        </View>
      )}
    </View>
  );
}
